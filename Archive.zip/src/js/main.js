'use strict';

(()=>{
    const name = 'MoMo';
    console.log(`Hello ${name}!`);
})();